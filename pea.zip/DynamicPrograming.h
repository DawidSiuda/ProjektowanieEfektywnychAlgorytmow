#pragma once

int dynamicPrograming(int** array, int width, bool test = false);
