#pragma once

int brutalForce(int **array, int width);

